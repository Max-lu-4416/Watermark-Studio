import { renderCanvas } from "./canvas-renderer.js";

function getExportFileName(sourceFileName) {
  const baseName = sourceFileName.replace(/\.[^.]+$/, "") || "watermarked-image";
  return `${baseName}-watermarked.jpg`;
}

export function exportJpg(state, quality = 0.92) {
  if (!state.sourceImage || !state.watermarkImage) {
    throw new Error("请先导入图片，并确认默认水印已加载");
  }

  const exportCanvas = document.createElement("canvas");
  renderCanvas(exportCanvas, state.sourceImage, state.watermarkImage, state.settings, {
    fullSize: true,
  });

  const link = document.createElement("a");
  link.href = exportCanvas.toDataURL("image/jpeg", quality);
  link.download = getExportFileName(state.sourceFileName);
  document.body.appendChild(link);
  link.click();
  link.remove();
}
