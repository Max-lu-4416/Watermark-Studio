# Watermark Studio

Watermark Studio is a local HTML/CSS/JavaScript canvas app for adding a transparent PNG watermark to photos.

## Features

- Import one local image.
- Automatically load `assets/watermarks/watermark.png` as the default watermark.
- Preview the image and watermark on canvas.
- Adjust watermark size, opacity, position, and margin.
- Export a new JPG while preserving the original image aspect ratio.
- Keep all image processing local in the browser.

## Run Locally

Start a static file server from the project root:

```powershell
python -m http.server 4173 --bind 127.0.0.1
```

Then open:

```text
http://127.0.0.1:4173/
```

## Watermark File

Put your transparent PNG watermark here:

```text
assets/watermarks/watermark.png
```

## Project Structure

- `index.html`: App layout and controls.
- `styles.css`: App layout, preview area, and control styling.
- `js/main.js`: App bootstrap and default watermark loading.
- `js/state.js`: Shared app state and default settings.
- `js/canvas-renderer.js`: Canvas rendering, watermark placement, scaling, opacity, and export-size drawing.
- `js/watermark-image.js`: Local image and watermark loading helpers.
- `js/export.js`: JPG export flow.
- `js/ui.js`: UI event binding and status updates.
- `assets/watermarks/`: Default watermark asset folder.

## Future Batch Export

Batch export can be added by changing the single imported source image into a queue, reusing `renderCanvas()` for each image at full size, and downloading each output or packaging them into a ZIP.
