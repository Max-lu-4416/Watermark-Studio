function getContainSize(imageWidth, imageHeight, maxWidth, maxHeight) {
  const scale = Math.min(maxWidth / imageWidth, maxHeight / imageHeight, 1);

  return {
    width: Math.max(1, Math.round(imageWidth * scale)),
    height: Math.max(1, Math.round(imageHeight * scale)),
  };
}

function getWatermarkRect(canvasWidth, canvasHeight, watermarkImage, settings) {
  const watermarkWidth = canvasWidth * (settings.sizePercent / 100);
  const watermarkHeight = watermarkWidth * (watermarkImage.naturalHeight / watermarkImage.naturalWidth);
  const margin = Math.min(canvasWidth, canvasHeight) * (settings.marginPercent / 100);

  const positions = {
    "top-left": {
      x: margin,
      y: margin,
    },
    "top-right": {
      x: canvasWidth - watermarkWidth - margin,
      y: margin,
    },
    "bottom-left": {
      x: margin,
      y: canvasHeight - watermarkHeight - margin,
    },
    "bottom-right": {
      x: canvasWidth - watermarkWidth - margin,
      y: canvasHeight - watermarkHeight - margin,
    },
    center: {
      x: (canvasWidth - watermarkWidth) / 2,
      y: (canvasHeight - watermarkHeight) / 2,
    },
  };

  return {
    ...(positions[settings.position] || positions["bottom-right"]),
    width: watermarkWidth,
    height: watermarkHeight,
  };
}

export function renderCanvas(canvas, image, watermarkImage, settings, options = {}) {
  if (!canvas || !image) {
    return null;
  }

  const maxWidth = options.maxWidth || image.naturalWidth;
  const maxHeight = options.maxHeight || image.naturalHeight;
  const renderSize = options.fullSize
    ? { width: image.naturalWidth, height: image.naturalHeight }
    : getContainSize(image.naturalWidth, image.naturalHeight, maxWidth, maxHeight);
  const ctx = canvas.getContext("2d");

  canvas.width = renderSize.width;
  canvas.height = renderSize.height;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

  if (watermarkImage) {
    const rect = getWatermarkRect(canvas.width, canvas.height, watermarkImage, settings);
    ctx.save();
    ctx.globalAlpha = settings.opacity / 100;
    ctx.drawImage(watermarkImage, rect.x, rect.y, rect.width, rect.height);
    ctx.restore();
  }

  return {
    width: canvas.width,
    height: canvas.height,
  };
}
