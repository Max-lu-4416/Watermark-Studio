import { DEFAULT_WATERMARK_URL, setWatermarkImage } from "./state.js";
import { initUI, notifyWatermarkError, notifyWatermarkReady } from "./ui.js";
import { loadImageFromUrl } from "./watermark-image.js";

async function bootstrap() {
  initUI();

  try {
    const watermarkImage = await loadImageFromUrl(DEFAULT_WATERMARK_URL);
    setWatermarkImage(watermarkImage);
    notifyWatermarkReady();
  } catch (error) {
    notifyWatermarkError(error);
  }
}

bootstrap();
