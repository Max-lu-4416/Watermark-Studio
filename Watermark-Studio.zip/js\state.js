export const DEFAULT_WATERMARK_URL = "assets/watermarks/watermark.png";

export const state = {
  sourceImage: null,
  sourceFileName: "",
  watermarkImage: null,
  watermarkUrl: DEFAULT_WATERMARK_URL,
  settings: {
    sizePercent: 15,
    opacity: 100,
    position: "bottom-right",
    marginPercent: 4,
  },
};

export function updateSettings(partialSettings) {
  state.settings = {
    ...state.settings,
    ...partialSettings,
  };
}

export function setSourceImage(image, fileName) {
  state.sourceImage = image;
  state.sourceFileName = fileName;
}

export function setWatermarkImage(image) {
  state.watermarkImage = image;
}

export function canRender() {
  return Boolean(state.sourceImage && state.watermarkImage);
}
