import { canRender, setSourceImage, state, updateSettings } from "./state.js";
import { loadImageFromFile } from "./watermark-image.js";
import { renderCanvas } from "./canvas-renderer.js";
import { exportJpg } from "./export.js";

let elements = {};

function setStatus(message, isError = false) {
  elements.statusText.textContent = message;
  elements.statusText.classList.toggle("is-error", isError);
}

function updateControlLabels() {
  elements.sizeValue.textContent = `${state.settings.sizePercent}%`;
  elements.opacityValue.textContent = `${state.settings.opacity}%`;
  elements.marginValue.textContent = `${state.settings.marginPercent}%`;
}

function updateMeta() {
  const image = state.sourceImage;

  elements.exportButton.disabled = !canRender();
  elements.emptyState.classList.toggle("is-hidden", Boolean(image));

  if (!image) {
    elements.imageMeta.textContent = "尚未导入图片";
    elements.canvasMeta.textContent = "预览区";
    return;
  }

  elements.imageMeta.textContent = `${state.sourceFileName} · ${image.naturalWidth} x ${image.naturalHeight}px`;
  elements.canvasMeta.textContent = `原图比例 ${image.naturalWidth}:${image.naturalHeight}`;
}

function renderPreview() {
  updateControlLabels();
  updateMeta();

  if (!canRender()) {
    return;
  }

  const container = elements.previewCanvas.parentElement;
  renderCanvas(elements.previewCanvas, state.sourceImage, state.watermarkImage, state.settings, {
    maxWidth: Math.max(320, container.clientWidth - 36),
    maxHeight: Math.max(240, container.clientHeight - 36),
  });
}

async function handlePhotoInput(event) {
  const [file] = event.target.files;

  if (!file) {
    return;
  }

  try {
    setStatus("正在读取图片...");
    const image = await loadImageFromFile(file);
    setSourceImage(image, file.name);
    renderPreview();
    setStatus("图片已导入，可以调整水印并导出");
  } catch (error) {
    setStatus(error.message, true);
  }
}

function handleSettingsChange() {
  updateSettings({
    sizePercent: Number(elements.sizeRange.value),
    opacity: Number(elements.opacityRange.value),
    marginPercent: Number(elements.marginRange.value),
    position: elements.positionInputs.find((input) => input.checked)?.value || "bottom-right",
  });
  renderPreview();
}

function handleExport() {
  try {
    exportJpg(state);
    setStatus("JPG 已导出");
  } catch (error) {
    setStatus(error.message, true);
  }
}

export function initUI() {
  elements = {
    photoInput: document.querySelector("#photoInput"),
    imageMeta: document.querySelector("#imageMeta"),
    canvasMeta: document.querySelector("#canvasMeta"),
    previewCanvas: document.querySelector("#previewCanvas"),
    emptyState: document.querySelector("#emptyState"),
    sizeRange: document.querySelector("#sizeRange"),
    sizeValue: document.querySelector("#sizeValue"),
    opacityRange: document.querySelector("#opacityRange"),
    opacityValue: document.querySelector("#opacityValue"),
    marginRange: document.querySelector("#marginRange"),
    marginValue: document.querySelector("#marginValue"),
    positionInputs: [...document.querySelectorAll('input[name="position"]')],
    exportButton: document.querySelector("#exportButton"),
    statusText: document.querySelector("#statusText"),
  };

  elements.photoInput.addEventListener("change", handlePhotoInput);
  elements.sizeRange.addEventListener("input", handleSettingsChange);
  elements.opacityRange.addEventListener("input", handleSettingsChange);
  elements.marginRange.addEventListener("input", handleSettingsChange);
  elements.positionInputs.forEach((input) => input.addEventListener("change", handleSettingsChange));
  elements.exportButton.addEventListener("click", handleExport);
  window.addEventListener("resize", renderPreview);

  updateControlLabels();
  updateMeta();
}

export function notifyWatermarkReady() {
  renderPreview();
  setStatus("默认水印已加载，请导入图片");
}

export function notifyWatermarkError(error) {
  updateMeta();
  setStatus(`${error.message}。请确认水印文件路径正确`, true);
}
